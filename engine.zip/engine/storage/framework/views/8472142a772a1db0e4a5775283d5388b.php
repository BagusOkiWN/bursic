<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('preloader'); ?>
<div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
        <span class="dot"></span>
        <div class="dots">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- ***** Main Banner Area Start ***** -->
<div class="main-banner" id="top">
    <img src="assets/images/banner-plymouth.jpg" alt="Your Image Description" id="bg-image" />


    <div class="video-overlay header-text">
        <div class="caption">
            <h6>Bursa Classic</h6>
            <h2>Best<em> classic car dealer</em> in town!</h2>
            <div class="main-button">
                <a href="<?php echo e(route('contact')); ?>">Contact Us</a>
            </div>
        </div>
    </div>
</div>
<!-- ***** Main Banner Area End ***** -->

<!-- ***** Cars Starts ***** -->
<section class="section" id="trainers">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <div class="section-heading">
                    <h2>Classic <em>Cars</em></h2>
                    <img src="assets/images/line-dec.png" alt="">
                    <p>Temukan mobil classic impian anda!</p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $mobilList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4">
                <div class="trainer-item">
                    <div class="image-thumb">
                        <img src="uploads/<?php echo e($mobil->gambar); ?>" alt="<?php echo e($mobil->nama); ?>" style="width: 320px; height: 200px;">
                    </div>
                    <div class="down-content">
                        <span>
                            <sup>Rp</sup><?php echo e($mobil->harga); ?> &nbsp;
                        </span>
                        <h4><?php echo e($mobil->nama); ?></h4>
                        <!-- Add other car details here -->
                        <ul class="social-icons">
                            <li><a href="<?php echo e(route('cardetails', ['id' => $mobil->id])); ?>">+ View Car</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <br>

        <div class="main-button text-center">
            <a href="<?php echo e(route('cars')); ?>">View Cars</a>
        </div>
    </div>
</section>
<!-- ***** Cars Ends ***** -->

<section class="section section-bg" id="schedule" style="background-image: url(assets/images/about-fullscreen-1-1920x700.jpg)">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <div class="section-heading dark-bg">
                    <h2>Read <em>About Us</em></h2>
                    <img src="assets/images/line-dec.png" alt="">
                    <p>Selamat datang di BurSic, Bursa Classic yang menjadi pintu gerbang bagi para pecinta mobil klasik. Kami adalah platform jual beli yang didedikasikan untuk menghubungkan penggemar mobil klasik dengan keindahan dan keunikannya. Dengan semangat dan kecintaan terhadap warisan otomotif, BurSic menjadi tempat di mana sejarah berkendara bertemu dengan masa kini.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ***** Testimonials Item Start ***** -->
<section class="section" id="features">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 offset-lg-3">
                <div class="section-heading">
                    <h2>Read our <em>Testimonials</em></h2>
                    <img src="assets/images/line-dec.png" alt="waves">
                    <p>Berikut testimoni pengguna BurSic!</p>
                </div>
            </div>
            <div class="col-lg-6">
                <ul class="features-items">
                    <li class="feature-item">
                        <div class="left-icon">
                            <img src="assets/images/features-first-icon.png" alt="First One">
                        </div>
                        <div class="right-content">
                            <h4>Ammar</h4>
                            <p><em>"Saya benar-benar terkesan dengan pengalaman saya menggunakan BurSic. Mereka tidak hanya menyediakan platform yang aman untuk jual beli mobil klasik, tetapi juga membantu saya menemukan 'si permata langka' yang saya cari. Prosesnya sangat lancar, dan tim dukungan pelanggan mereka responsif dan membantu. Saya sangat merekomendasikan BurSic kepada semua penggemar mobil klasik!"</em></p>
                        </div>
                    </li>
                    <li class="feature-item">
                        <div class="left-icon">
                            <img src="assets/images/features-first-icon.png" alt="second one">
                        </div>
                        <div class="right-content">
                            <h4>Alfa</h4>
                            <p><em>"BurSic benar-benar menghadirkan revolusi dalam cara saya menjelajahi dan mengumpulkan mobil klasik. Dari desain situs yang estetis hingga alat pencarian yang canggih, saya merasa platform ini memberikan nilai tambah yang besar bagi para penggemar otomotif seperti saya."</em></p>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="col-lg-6">
                <ul class="features-items">
                    <li class="feature-item">
                        <div class="left-icon">
                            <img src="assets/images/features-first-icon.png" alt="fourth muscle">
                        </div>
                        <div class="right-content">
                            <h4>Adam</h4>
                            <p><em>"BurSic adalah tempat yang luar biasa untuk pecinta mobil klasik seperti saya. Antarmuka pengguna yang ramah pengguna membuat penelusuran dan penjelajahan menjadi pengalaman yang menyenangkan. Saya benar-benar terkesan dengan desain intuitifnya, yang membuat proses mencari dan memilih mobil klasik menjadi begitu mudah."</em></p>
                        </div>
                    </li>
                    <li class="feature-item">
                        <div class="left-icon">
                            <img src="assets/images/features-first-icon.png" alt="training fifth">
                        </div>
                        <div class="right-content">
                            <h4>Okik</h4>
                            <p><em>"Sebagai kolektor mobil klasik, saya sangat menghargai bahwa BurSic tidak hanya fokus pada penampilan visual, tetapi juga menyediakan detail-detail teknis yang penting. Ini membantu saya memilih mobil yang sesuai dengan keinginan koleksi saya, dan saya merasa pasti bahwa setiap mobil yang saya beli dari BurSic memiliki riwayat yang terdokumentasi dengan baik."</em></p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

        <br>

        <div class="main-button text-center">
            <a href="<?php echo e(route('testimonials')); ?>">Read More</a>
        </div>
    </div>
</section>

<!-- ***** Call to Action Start ***** -->
<section class="section section-bg" id="call-to-action" style="background-image: url(assets/images/mstg.jpg)">
    <div class="container">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <div class="cta-content">
                    <h2>Send us a <em>message</em></h2>
                    <p>Your thoughts matter! Send us a message if you have any inquiries, suggestions, or just want to chat about classic cars.</p>
                    <div class="main-button">
                        <a href="<?php echo e(route('contact')); ?>">Contact us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ***** Call to Action End ***** -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('aditional-css'); ?>
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

<link rel="stylesheet" href="assets/css/style.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('aditional-js'); ?>
<!-- jQuery -->
<script src="assets/js/jquery-2.1.0.min.js"></script>

<!-- Bootstrap -->
<script src="assets/js/popper.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<!-- Plugins -->
<script src="assets/js/scrollreveal.min.js"></script>
<script src="assets/js/waypoints.min.js"></script>
<script src="assets/js/jquery.counterup.min.js"></script>
<script src="assets/js/imgfix.min.js"></script>
<script src="assets/js/mixitup.js"></script>
<script src="assets/js/accordions.js"></script>

<!-- Global Init -->
<script src="assets/js/custom.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('pages.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\xampp\htdocs\bursic\engine\resources\views/pages/home.blade.php ENDPATH**/ ?>