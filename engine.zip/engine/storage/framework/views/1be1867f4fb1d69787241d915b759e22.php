<?php $__env->startSection('title', 'Car Details'); ?>

<?php $__env->startSection('preloader'); ?>
    <div id="js-preloader" class="js-preloader">
      <div class="preloader-inner">
        <span class="dot"></span>
        <div class="dots">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <!-- ***** Call to Action Start ***** -->
    <section class="section section-bg" id="call-to-action" style="background-image: url(assets/images/mstg.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="cta-content">
                        <br>
                        <br>
                        <h2>CAR <em>DETAILS</em></h2>
                        <p></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Call to Action End ***** -->

    <!-- ***** Fleet Starts ***** -->
    <section class="section" id="trainers">
        <div class="container">
            <br>
            <br>

            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
              <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
              </ol>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img class="d-block w-100" src="<?php echo e(asset('uploads/' . $car->gambar)); ?>" alt="<?php echo e($car->name); ?>">
                </div>
            </div>
            
            <br>
            <br>

            <div class="row" id="tabs">
              <div class="col-lg-4">
                <ul>
                  <li><a href='#tabs-1'><i class="fa fa-cog"></i> Vehicle Specs</a></li>
                  <li><a href='#tabs-2'><i class="fa fa-info-circle"></i> Vehicle Description</a></li>
                  <!-- <li><a href='#tabs-3'><i class="fa fa-plus-circle"></i> Vehicle Extras</a></li> -->
                  <li><a href='#tabs-4'><i class="fa fa-phone"></i> Contact Details</a></li>
                </ul>
              </div>
              <div class="col-lg-8">
                <section class='tabs-content' style="width: 100%;">
                  <article id='tabs-1'>
                    <h4>Vehicle Specs</h4>

                    <div class="row">
                       <div class="col-sm-6">
                            <label>Type</label>
                       
                            <p><?php echo e($car->type); ?></p>
                       </div>

                       <div class="col-sm-6">
                            <label>Model</label>
                       
                            <p><?php echo e($car->nama); ?></p>
                       </div>

                       <div class="col-sm-6">
                            <label>Year</label>
                       
                            <p><?php echo e($car->tahun); ?></p>
                       </div>

                       <div class="col-sm-6">
                            <label>Color</label>
                       
                            <p><?php echo e($car->warna); ?></p>
                       </div>

                       <div class="col-sm-6">
                            <label>Seats</label>
                       
                            <p><?php echo e($car->kursi); ?></p>
                       </div>

                       <div class="col-sm-6">
                            <label>Doors</label>
                       
                            <p><?php echo e($car->pintu); ?></p>
                       </div>


                       <div class="col-sm-6">
                            <label>Fuel</label>
                       
                            <p><?php echo e($car->bbm); ?></p>
                       </div>

                       <div class="col-sm-6">
                            <label>Mileage</label>
                       
                            <p><?php echo e($car->km); ?></p>
                       </div>

                       <div class="col-sm-6">
                            <label>Engine Size (CC)</label>
                       
                            <p><?php echo e($car->cc); ?></p>
                       </div>

                       <div class="col-sm-6">
                            <label>Power (HP)</label>
                       
                            <p><?php echo e($car->power); ?></p>
                       </div>
                    </div>
                  </article>
                  <article id='tabs-2'>
                    <h4>Vehicle Description</h4>
                    
                    <p><?php echo e($car->description); ?></p> 
                   </article>

                  <article id='tabs-4'>
                    <h4>Contact Details</h4>

                    <div class="row">   
                        <div class="col-sm-6">
                            <label>Seller Name</label>

                            <p><?php echo e($car->penjual); ?></p>
                        </div>
                        <div class="col-sm-6">
                            <label>Seller Phone</label>

                            <p><?php echo e($car->telepon); ?></p>
                        </div>
                    </div>
                  </article>
                </section>
              </div>
            </div>
        </div>
    </section>
    <!-- ***** Fleet Ends ***** -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('aditional-css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/font-awesome.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('aditional-js'); ?>
<!-- jQuery -->
<script src="<?php echo e(asset('assets/js/jquery-2.1.0.min.js')); ?>"></script>

<!-- Bootstrap -->
<script src="<?php echo e(asset('assets/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

<!-- Plugins -->
<script src="<?php echo e(asset('assets/js/scrollreveal.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/imgfix.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/mixitup.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/accordions.js')); ?>"></script>

<!-- Global Init -->
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('pages.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\xampp\htdocs\bursic\engine\resources\views/pages/car-details.blade.php ENDPATH**/ ?>