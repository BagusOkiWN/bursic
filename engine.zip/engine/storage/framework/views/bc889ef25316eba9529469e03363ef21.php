<header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="<?php echo e(route('home')); ?>" class="logo">Bur<em>Sic</em></a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('cars')); ?>">Cars</a></li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">About</a>

                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="<?php echo e(route('about')); ?>">About Us</a>
                                <!-- <a class="dropdown-item" href="<?php echo e(route('blog')); ?>">Blog</a> -->
                                <a class="dropdown-item" href="<?php echo e(route('team')); ?>">Team</a>
                                <a class="dropdown-item" href="<?php echo e(route('testimonials')); ?>">Testimonials</a>
                                <a class="dropdown-item" href="<?php echo e(route('faq')); ?>">FAQ</a>
                                <!-- <a class="dropdown-item" href="<?php echo e(route('terms')); ?>">Terms</a> -->
                            </div>
                        </li>
                        <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                        <div class="row">
    <?php if(empty(auth()->user()->name)): ?>
        <div class="col-lg-12 text-center">
            <a href="<?php echo e(route('auth')); ?>" class="btn btn-success">Masuk</a>
        </div>
    <?php endif; ?>

    <?php if(!empty(auth()->user()->name)): ?>
        <div class="col-lg-12 text-center">
        <a href="<?php echo e(route('form-mobil')); ?>" class="btn btn-danger">Jual Mobil</a>
            <div class="btn-group">
                
                <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo e(auth()->user()->name); ?>

                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Log Out</a>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

                    </ul>
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
</header><?php /**PATH D:\Program Files\xampp\htdocs\bursic\engine\resources\views/pages/navbar.blade.php ENDPATH**/ ?>