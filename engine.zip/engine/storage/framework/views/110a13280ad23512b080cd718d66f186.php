<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldPushContent('aditional-css'); ?>
</head>
<body>
    <div>
        <?php echo $__env->yieldContent('preloader'); ?>
        <?php echo $__env->make('pages.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('pages.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>    

    <?php echo $__env->yieldPushContent('aditional-js'); ?>
</body>
</html><?php /**PATH D:\Program Files\xampp\htdocs\bursic\engine\resources\views/pages/master.blade.php ENDPATH**/ ?>