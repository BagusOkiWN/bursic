<footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p>
                        Copyright © 2023 BurSic
    
                    </p>
                </div>
            </div>
        </div>
    </footer><?php /**PATH D:\Program Files\xampp\htdocs\bursic\engine\resources\views/pages/footer.blade.php ENDPATH**/ ?>